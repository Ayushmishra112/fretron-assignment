#include <iostream>
#include <vector>
#include <set>
#include <sstream>

using namespace std;

// Define the grid size for simplicity
const int GRID_SIZE = 10;

// Function to plot a flight path on a grid
void plotFlightPath(vector<pair<int, int>>& path, char grid[GRID_SIZE][GRID_SIZE], char marker) {
    for (const auto& coord : path) {
        int x = coord.first;
        int y = coord.second;
        if (x >= 0 && x < GRID_SIZE && y >= 0 && y < GRID_SIZE) {
            grid[x][y] = marker;
        }
    }
}

// Function to display the grid
void displayGrid(char grid[GRID_SIZE][GRID_SIZE]) {
    for (int i = 0; i < GRID_SIZE; ++i) {
        for (int j = 0; j < GRID_SIZE; ++j) {
            cout << grid[i][j] << " ";
        }
        cout << endl;
    }
}

// Function to parse input coordinates
vector<pair<int, int>> parseCoordinates(const string& line) {
    vector<pair<int, int>> coordinates;
    stringstream ss(line);
    string token;
    while (getline(ss, token, ' ')) {
        int x, y;
        sscanf(token.c_str(), "%d,%d", &x, &y);
        coordinates.push_back({x, y});
    }
    return coordinates;
}

int main() {
    // Initialize the grid
    char grid[GRID_SIZE][GRID_SIZE];
    for (int i = 0; i < GRID_SIZE; ++i) {
        for (int j = 0; j < GRID_SIZE; ++j) {
            grid[i][j] = '.';
        }
    }

    // Input flight paths
    string flight1, flight2, flight3;
    cout << "Enter coordinates for Flight 1: ";
    getline(cin, flight1);
    cout << "Enter coordinates for Flight 2: ";
    getline(cin, flight2);
    cout << "Enter coordinates for Flight 3: ";
    getline(cin, flight3);

    // Parse flight paths
    vector<pair<int, int>> path1 = parseCoordinates(flight1);
    vector<pair<int, int>> path2 = parseCoordinates(flight2);
    vector<pair<int, int>> path3 = parseCoordinates(flight3);

    // Plot flight paths on the grid
    plotFlightPath(path1, grid, '1');
    plotFlightPath(path2, grid, '2');
    plotFlightPath(path3, grid, '3');

    // Display the grid with flight paths
    cout << "Flight paths on the grid:" << endl;
    displayGrid(grid);

    return 0;
}
