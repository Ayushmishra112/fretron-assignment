#include <iostream>
#include <vector>
#include <algorithm>
#include <numeric>

using namespace std;

void printDistribution(const vector<int>& ram, const vector<int>& sham, const vector<int>& rahim) {
    cout << "Distribution Result:\n";
    cout << "Ram: ";
    for (const auto& apple : ram) {
        cout << apple << " ";
    }
    cout << "\nSham: ";
    for (const auto& apple : sham) {
        cout << apple << " ";
    }
    cout << "\nRahim: ";
    for (const auto& apple : rahim) {
        cout << apple << " ";
    }
    cout << endl;
}

int main() {
    vector<int> apples;
    int weight;
    
    cout << "run distribute_apple" << endl;
    cout << "Enter apple weight in gram (-1 to stop): ";
    while (cin >> weight && weight != -1) {
        apples.push_back(weight);
        cout << "Enter apple weight in gram (-1 to stop): ";
    }

    
    sort(apples.rbegin(), apples.rend());

    int totalAmount = 50 + 30 + 20;
    double ramShare = 50.0 / totalAmount;
    double shamShare = 30.0 / totalAmount;
    double rahimShare = 20.0 / totalAmount;

    vector<int> ram, sham, rahim;
    int ramTotal = 0, shamTotal = 0, rahimTotal = 0;
    double ramCurrentShare = 0.0, shamCurrentShare = 0.0, rahimCurrentShare = 0.0;

    for (const auto& apple : apples) {
        if (ramCurrentShare <= shamCurrentShare && ramCurrentShare <= rahimCurrentShare) {
            ram.push_back(apple);
            ramTotal += apple;
            ramCurrentShare = static_cast<double>(ramTotal) / accumulate(apples.begin(), apples.end(), 0);
        } else if (shamCurrentShare <= rahimCurrentShare) {
            sham.push_back(apple);
            shamTotal += apple;
            shamCurrentShare = static_cast<double>(shamTotal) / accumulate(apples.begin(), apples.end(), 0);
        } else {
            rahim.push_back(apple);
            rahimTotal += apple;
            rahimCurrentShare = static_cast<double>(rahimTotal) / accumulate(apples.begin(), apples.end(), 0);
        }
    }

    printDistribution(ram, sham, rahim);

    return 0;
}

